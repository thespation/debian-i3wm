# ------------------------------------------------------------------------------
# Everforest Theme - Adaptado para seu setup
# ------------------------------------------------------------------------------

# Colors (Everforest Dark)
background='#2b3339'
foreground='#d3c6aa'
color0='#323c41'
color1='#e67e80'
color2='#a7c080'
color3='#dbbc7f'
color4='#7fbbb3'
color5='#d699b6'
color6='#83c092'
color7='#d3c6aa'
color8='#3b4248'
color9='#e69875'
color10='#a7c080'
color11='#dbbc7f'
color12='#7fbbb3'
color13='#d699b6'
color14='#83c092'
color15='#fdf6e3'

accent='#a7c080'
light_value='0.04'
dark_value='0.25'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Arc-Circle'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='8'

# Geany
geany_colors='everforest-dark.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='Everforest-Dark'
icon_theme='Nordic-Folders-Green'
cursor_theme='Future'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'
