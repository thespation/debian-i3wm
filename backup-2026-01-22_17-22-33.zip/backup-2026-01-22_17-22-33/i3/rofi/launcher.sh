#!/usr/bin/env bash

# ┌┬┐┌─┐┌┐┌┬ ┬  ┌┬┐┌─┐  ┌─┐┌─┐┬  ┬┌─┐┌─┐┌┬┐┬┬  ┬┌─┐┌─┐
# │││├┤ ││││ │   ││├┤   ├─┤├─┘│  ││  ├─┤ │ │└┐┌┘│ │└─┐
# ┴ ┴└─┘┘└┘└─┘  ─┴┘└─┘  ┴ ┴┴  ┴─┘┴└─┘┴ ┴ ┴ ┴ └┘ └─┘└─┘

# Tema do rofi
DIR="$HOME/.config/i3"
STYLE_FILE="$DIR/themes/.current"

[ -f "$STYLE_FILE" ] || exit 1
STYLE=$(<"$STYLE_FILE")

THEME_DIR="$DIR/themes/$STYLE"
ROFI_DIR="$THEME_DIR/rofi"

# Segurança básica
[ -d "$ROFI_DIR" ] || exit 1

cd "$ROFI_DIR" || exit 1

# Run
rofi \
    -show drun \
    -kb-cancel "Escape,Control+c,Alt+F1" \
    -theme launcher.rasi
