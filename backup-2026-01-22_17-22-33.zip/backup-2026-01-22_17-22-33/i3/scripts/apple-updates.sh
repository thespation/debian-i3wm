#!/usr/bin/env bash

# ┌─┐┌─┐┬  ┬┌─┐┌─┐┬─┐  ┌─┐┌┬┐┬ ┬┌─┐┬  ┬┌─┐┌─┐┌─┐┌─┐
# ├─┤├─┘│  ││  ├─┤├┬┘  ├─┤ │ │ │├─┤│  │┌─┘│  ├─┤│ │
# ┴ ┴┴  ┴─┘┴└─┘┴ ┴┴└─  ┴ ┴ ┴ └─┘┴ ┴┴─┘┴└─┘└─┘┴ ┴└─┘
# Abre o Alacritty e aplica as atualizações usando nala

# Abre o Alacritty com uma classe única (identificação)
alacritty --class UpdateTerm,UpdateTerm -e bash -c '
    echo "🔄 Atualizando o sistema"
    sudo nala update && sudo nala upgrade
    echo ""
    echo "✔ Atualização concluída!"
    read -p "Pressione ENTER para fechar..."
' &

# Espera a janela aparecer (ajuste se necessário)
sleep 0.5

# Coloca SOMENTE essa janela em floating, centraliza e ajusta tamanho
i3-msg '[class="UpdateTerm"] floating enable; resize set 900 600; move position center'
