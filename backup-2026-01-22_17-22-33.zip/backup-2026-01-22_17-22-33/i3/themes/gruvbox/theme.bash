# ┌─┐┬─┐┬ ┬┬  ┬┌┐ ┌─┐─┐ ┬  ┌┬┐┌─┐┌┬┐┌─┐
# │ ┬├┬┘│ │└┐┌┘├┴┐│ │┌┴┬┘   │ ├┤ │││├─┤
# └─┘┴└─└─┘ └┘ └─┘└─┘┴ └─   ┴ └─┘┴ ┴┴ ┴

# Colors (Gruvbox Dark Hard)
background='#1d2021'
foreground='#ebdbb2'
color0='#282828'
color1='#fb4934'
color2='#b8bb26'
color3='#fabd2f'
color4='#83a598'
color5='#d3869b'
color6='#8ec07c'
color7='#d5c4a1'
color8='#3c3836'
color9='#fe8019'
color10='#b8bb26'
color11='#fabd2f'
color12='#83a598'
color13='#d3869b'
color14='#8ec07c'
color15='#fbf1c7'

accent='#fabd2f'
light_value='0.04'
dark_value='0.25'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Nordic-Folders-Green'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='8'

# Geany
geany_colors='gruvbox-dark.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='Gruvbox-Dark'
icon_theme='Nordic-Folders-Green'
cursor_theme='Future'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'
