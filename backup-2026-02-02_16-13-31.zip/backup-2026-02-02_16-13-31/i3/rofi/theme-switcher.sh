#!/usr/bin/env bash
set -euo pipefail

# ┌┬┐┬─┐┌─┐┌─┐┌─┐  ┌┬┐┌─┐  ┌┬┐┌─┐┌┬┐┌─┐┌─┐   ┬┌─┐┌─┐┌┐┌┌─┐┌─┐  ┌─┐  ┌─┐┬ ┬┬─┐┌─┐┌─┐┬─┐
#  │ ├┬┘│ ││  ├─┤   ││├┤    │ ├┤ │││├─┤└─┐   ││  │ ││││├┤ └─┐  ├┤   │  │ │├┬┘└─┐│ │├┬┘
#  ┴ ┴└─└─┘└─┘┴ ┴  ─┴┘└─┘   ┴ └─┘┴ ┴┴ ┴└─┘┘  ┴└─┘└─┘┘└┘└─┘└─┘  └─┘  └─┘└─┘┴└─└─┘└─┘┴└─

# --------------------------------------------------
# Diretórios
# --------------------------------------------------
DIR="$HOME/.config/i3"
STYLE_FILE="$DIR/themes/.current"

[ -f "$STYLE_FILE" ] || exit 1
STYLE="$(<"$STYLE_FILE")"

THEME_DIR="$DIR/themes/$STYLE"
ROFI_DIR="$THEME_DIR/rofi"
RASI="$ROFI_DIR/themes-switcher.rasi"

# Segurança
[ -d "$ROFI_DIR" ] || exit 1
[ -f "$RASI" ] || exit 1

GTK_DIR="/usr/share/themes"
ICON_DIR="/usr/share/icons"

# --------------------------------------------------
# ESSENCIAL: entrar no diretório do rofi
# --------------------------------------------------
cd "$ROFI_DIR" || exit 1

# --------------------------------------------------
# Funções
# --------------------------------------------------
change_gtk_theme() {
    theme=$(ls "$GTK_DIR" | rofi -dmenu -i -p "Tema GTK" -theme "$RASI")
    [ -n "$theme" ] && gsettings set org.gnome.desktop.interface gtk-theme "$theme"
}

change_icon_theme() {
    theme=$(ls "$ICON_DIR" | rofi -dmenu -i -p "Tema Ícones" -theme "$RASI")
    [ -n "$theme" ] && gsettings set org.gnome.desktop.interface icon-theme "$theme"
}

change_cursor_theme() {
    theme=$(ls "$ICON_DIR" | rofi -dmenu -i -p "Tema Cursor" -theme "$RASI")
    [ -n "$theme" ] && gsettings set org.gnome.desktop.interface cursor-theme "$theme"
}

# --------------------------------------------------
# Menu principal
# --------------------------------------------------
option=$(printf "Tema GTK\nTema Ícones\nTema Cursor" | rofi -dmenu -i -p "Aparência" -theme "$RASI")

case "$option" in
    "Tema GTK") change_gtk_theme ;;
    "Tema Ícones") change_icon_theme ;;
    "Tema Cursor") change_cursor_theme ;;
    *) exit 0 ;;
esac
