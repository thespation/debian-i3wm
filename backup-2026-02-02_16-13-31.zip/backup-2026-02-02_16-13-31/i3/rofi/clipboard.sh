#!/usr/bin/env bash

# Clipboard manager for Debian + i3wm (X11)
# Uses i3 theme structure with .current

# =========================
# Tema do rofi
# =========================
DIR="$HOME/.config/i3"
STYLE_FILE="$DIR/themes/.current"

[ -f "$STYLE_FILE" ] || exit 1
STYLE=$(<"$STYLE_FILE")

THEME_DIR="$DIR/themes/$STYLE"
ROFI_DIR="$THEME_DIR/rofi"

# Segurança básica
[ -d "$ROFI_DIR" ] || exit 1

cd "$ROFI_DIR" || exit 1

# =========================
# Dependências
# =========================
for cmd in cliphist rofi xclip; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
        notify-send "Clipboard" "Dependência ausente: $cmd"
        exit 1
    fi
done

# =========================
# Configurações Rofi
# =========================
ROFI_PROMPT="Clipboard"
ROFI_LINES=12
ROFI_WIDTH=60
ROFI_MESSAGE="Digite 'limpar' para apagar o histórico"

# =========================
# Execução
# =========================
SELECTION=$(
    cliphist list | rofi -dmenu \
        -i \
        -p "$ROFI_PROMPT" \
        -lines "$ROFI_LINES" \
        -width "$ROFI_WIDTH" \
        -mesg "$ROFI_MESSAGE" \
        -theme clipboard.rasi
)

# Se nada for selecionado, sai
[ -z "$SELECTION" ] && exit 0

# =========================
# Ações
# =========================
if [ "$SELECTION" = "limpar" ]; then
    cliphist wipe
    notify-send "Clipboard" "Histórico limpo"
    exit 0
fi

# Copia seleção para o clipboard
echo "$SELECTION" | cliphist decode | xclip -selection clipboard
