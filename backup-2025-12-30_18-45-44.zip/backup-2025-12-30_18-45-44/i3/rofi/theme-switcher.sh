#!/usr/bin/env bash

# ┌┬┐┬─┐┌─┐┌─┐┌─┐  ┌┬┐┌─┐  ┌┬┐┌─┐┌┬┐┌─┐┌─┐   ┬┌─┐┌─┐┌┐┌┌─┐┌─┐  ┌─┐  ┌─┐┬ ┬┬─┐┌─┐┌─┐┬─┐
#  │ ├┬┘│ ││  ├─┤   ││├┤    │ ├┤ │││├─┤└─┐   ││  │ ││││├┤ └─┐  ├┤   │  │ │├┬┘└─┐│ │├┬┘
#  ┴ ┴└─└─┘└─┘┴ ┴  ─┴┘└─┘   ┴ └─┘┴ ┴┴ ┴└─┘┘  ┴└─┘└─┘┘└┘└─┘└─┘  └─┘  └─┘└─┘┴└─└─┘└─┘┴└─

# Tema do rofi
DIR="$HOME/.config/i3"
STYLE=$(cat "$DIR/themes/.current")
RASI="$DIR/themes/$STYLE/rofi/themes-switcher.rasi"

GTK_DIR="/usr/share/themes"
ICON_DIR="/usr/share/icons"

### Função para selecionar tema GTK
change_gtk_theme() {
    theme=$(ls "$GTK_DIR" | rofi -dmenu -i -p "Tema GTK" -theme "$RASI")
    [ -n "$theme" ] && gsettings set org.gnome.desktop.interface gtk-theme "$theme"
}

### Função para selecionar tema de ícones
change_icon_theme() {
    theme=$(ls "$ICON_DIR" | rofi -dmenu -i -p "Tema Ícones" -theme "$RASI")
    [ -n "$theme" ] && gsettings set org.gnome.desktop.interface icon-theme "$theme"
}

### Função para selecionar cursor (opcional)
change_cursor_theme() {
    theme=$(ls "$ICON_DIR" | rofi -dmenu -i -p "Tema Cursor" -theme "$RASI")
    [ -n "$theme" ] && gsettings set org.gnome.desktop.interface cursor-theme "$theme"
}

### Menu principal
option=$(printf "Tema GTK\nTema Ícones\nTema Cursor" | rofi -dmenu -i -p "Aparência" -theme "$RASI")

case "$option" in
    "Tema GTK") change_gtk_theme ;;
    "Tema Ícones") change_icon_theme ;;
    "Tema Cursor") change_cursor_theme ;;
    *) exit 0 ;;
esac
