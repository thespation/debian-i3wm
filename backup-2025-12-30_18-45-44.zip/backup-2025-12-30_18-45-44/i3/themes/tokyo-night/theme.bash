# ------------------------------------------------------------------------------
# Tokyo Night Theme - Adaptado para seu setup
# ------------------------------------------------------------------------------

# Colors (Tokyo Night)
background='#1a1b26'
foreground='#c0caf5'
color0='#16161e'
color1='#f7768e'
color2='#9ece6a'
color3='#e0af68'
color4='#7aa2f7'
color5='#bb9af7'
color6='#73daca'
color7='#a9b1d6'
color8='#2a2e3f'
color9='#ff9e64'
color10='#9ece6a'
color11='#e0af68'
color12='#7aa2f7'
color13='#bb9af7'
color14='#73daca'
color15='#d5d6db'

accent='#7aa2f7'
light_value='0.04'
dark_value='0.25'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Arc-Circle'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='8'

# Geany
geany_colors='tokyo-night.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='Tokyonight-Dark'
icon_theme='Luv-Folders-Dark'
cursor_theme='Future'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'

# Picom
picom_backend='glx'
picom_corner='0'
picom_shadow_r='20'
picom_shadow_o='0.50'
picom_shadow_x='-20'
picom_shadow_y='-20'
picom_blur_method='none'
picom_blur_strength='0'

# Bspwm
bspwm_fbc="$accent"
bspwm_nbc="$background"
bspwm_abc="#bb9af7"
bspwm_pfc="#9ece6a"
bspwm_border='2'
bspwm_gap='20'
bspwm_sratio='0.50'

# ------------------------------------------------------------------------------
# Comentários das cores - Tokyo Night
# ------------------------------------------------------------------------------
# background -> fundo preto-azulado
# foreground -> branco azulado (texto padrão)
# color0     -> preto profundo
# color1     -> vermelho/rosa intenso
# color2     -> verde claro
# color3     -> amarelo dourado
# color4     -> azul vibrante
# color5     -> roxo neon
# color6     -> aqua/verde-azulado
# color7     -> cinza azulado (texto alternativo)
# color8     -> azul escuro acinzentado
# color9     -> laranja vibrante
# color10    -> verde claro (bright)
# color11    -> amarelo dourado (bright)
# color12    -> azul vibrante (bright)
# color13    -> roxo neon (bright)
# color14    -> aqua/verde-azulado (bright)
# color15    -> branco suave
