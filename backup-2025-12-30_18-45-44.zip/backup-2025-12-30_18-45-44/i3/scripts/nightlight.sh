#!/bin/bash

# ┌─┐┌┬┐┬┬  ┬┌─┐  ┌─┐┬ ┬  ┌┬┐┌─┐┌─┐┌─┐┌┬┐┬┬  ┬┌─┐  ┬  ┬ ┬┌─┐  ┌┐┌┌─┐┌┬┐┬ ┬┬─┐┌┐┌┌─┐
# ├─┤ │ │└┐┌┘├─┤  │ ││ │   ││├┤ └─┐├─┤ │ │└┐┌┘├─┤  │  │ │┌─┘  ││││ │ │ │ │├┬┘│││├─┤
# ┴ ┴ ┴ ┴ └┘ ┴ ┴  └─┘└─┘  ─┴┘└─┘└─┘┴ ┴ ┴ ┴ └┘ ┴ ┴  ┴─┘└─┘└─┘  ┘└┘└─┘ ┴ └─┘┴└─┘└┘┴ ┴

STATE_FILE="/tmp/nightlight_state"

# Se não existir, assume desligado
if [ ! -f "$STATE_FILE" ]; then
    echo "off" > "$STATE_FILE"
fi

STATE=$(cat "$STATE_FILE")

case "$1" in
    toggle)
        if [ "$STATE" = "off" ]; then
            # Ativar luz noturna
            gammastep -O 3500K
            echo "on" > "$STATE_FILE"
        else
            # Desativar luz noturna
            gammastep -x
            echo "off" > "$STATE_FILE"
        fi
        ;;
    *)
        # Apenas mostrar o ícone
        if [ "$STATE" = "off" ]; then
            echo ""   # sol
        else
            echo ""   # lua
        fi
        ;;
esac
