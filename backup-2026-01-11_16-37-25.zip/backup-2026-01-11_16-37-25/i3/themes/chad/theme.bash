# ------------------------------------------------------------------------------
# Nord Theme - Adaptado para seu setup
# ------------------------------------------------------------------------------

# Colors
background='#1E2327'
foreground='#D8DEE9'
color0='#3B4252'
color1='#BF616A'
color2='#A3BE8C'
color3='#EBCB8B'
color4='#81A1C1'
color5='#B48EAD'
color6='#88C0D0'
color7='#E5E9F0'
color8='#434C5E'
color9='#D08770'
color10='#8FBCBB'
color11='#EBCB8B'
color12='#5E81AC'
color13='#B48EAD'
color14='#A3BE8C'
color15='#ECEFF4'

accent='#88C0D0'
light_value='0.04'
dark_value='0.25'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Arc-Circle'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='8'

# Geany
geany_colors='chad.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='Everforest'
icon_theme='Colloid-Dark'
cursor_theme='Future'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'
