#!/usr/bin/env bash

# ┌┬┐┌─┐┌┐┌┬ ┬  ┌┬┐┌─┐  ┌─┐┌─┐┬  ┬┌─┐┌─┐┌┬┐┬┬  ┬┌─┐┌─┐
# │││├┤ ││││ │   ││├┤   ├─┤├─┘│  ││  ├─┤ │ │└┐┌┘│ │└─┐
# ┴ ┴└─┘┘└┘└─┘  ─┴┘└─┘  ┴ ┴┴  ┴─┘┴└─┘┴ ┴ ┴ ┴ └┘ └─┘└─┘

# Tema do rofi
DIR="$HOME/.config/i3"
STYLE=$(cat "$DIR/themes/.current")
RASI="$DIR/themes/$STYLE/rofi/launcher.rasi"

# Run
rofi \
    -show drun \
    -kb-cancel "Escape,Control+c,Alt+F1" \
    -theme "${RASI}"
