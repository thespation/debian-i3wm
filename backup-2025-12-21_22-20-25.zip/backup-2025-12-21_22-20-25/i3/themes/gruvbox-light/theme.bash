# ------------------------------------------------------------------------------
# Gruvbox Theme - Adaptado para seu setup (VERSÃO LIGHT)
# ------------------------------------------------------------------------------

# Colors (Gruvbox Light Hard)
background='#fbf1c7'
foreground='#3c3836'
color0='#f9f5d7'
color1='#cc241d'
color2='#98971a'
color3='#d79921'
color4='#458588'
color5='#b16286'
color6='#689d6a'
color7='#7c6f64'
color8='#ebdbb2'
color9='#9d0006'
color10='#79740e'
color11='#b57614'
color12='#076678'
color13='#8f3f71'
color14='#427b58'
color15='#1d2021'

accent='#d79921'
light_value='0.10'
dark_value='0.20'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Win11'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='8'

# Geany
geany_colors='gruvbox-light.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='Gruvbox-Light'
icon_theme='Win11'
cursor_theme='Future'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'

# Picom
picom_backend='glx'
picom_corner='0'
picom_shadow_r='10'
picom_shadow_o='0.20'
picom_shadow_x='-10'
picom_shadow_y='-10'
picom_blur_method='none'
picom_blur_strength='0'
