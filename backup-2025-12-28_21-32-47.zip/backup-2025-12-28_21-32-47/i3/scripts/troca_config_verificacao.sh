#!/bin/bash

# ┌─┐┌─┐┌─┐┌─┐┌─┐┬─┐  ┌─┐┌─┐┬─┐┌─┐  ┌┐┌┬ ┬┌┬┐┌─┐┬─┐┌─┐┌─┐  ┌─┐┬ ┬  ┬┌─┐┌─┐┌┐┌┌─┐┌─┐
# ├─┘├─┤└─┐└─┐├─┤├┬┘  ├─┘├─┤├┬┘├─┤  ││││ ││││├┤ ├┬┘│ │└─┐  │ ││ │  ││  │ ││││├┤ └─┐
# ┴  ┴ ┴└─┘└─┘┴ ┴┴└─  ┴  ┴ ┴┴└─┴ ┴  ┘└┘└─┘┴ ┴└─┘┴└─└─┘└─┘  └─┘└─┘  ┴└─┘└─┘┘└┘└─┘└─┘
# Modifica a exebicao da workstations da polybar entre modo numero ou icones

# Caminho base
PATH_I3="$HOME/.config/i3"

# Arquivo com o nome do tema atual
theme_file="$PATH_I3/themes/.current"

# Nome do tema atual
current_theme=$(cat "$theme_file")

# Caminho do config
CONFIG_FILE="$PATH_I3/themes/$current_theme/polybar/config.ini"

# Verifica se modules-left contém i3_numbers
if grep -qE '^modules-left\s*=.*\bi3_numbers\b' "$CONFIG_FILE"; then
    # Troca i3_numbers -> i3
    sed -i -E 's/\bi3_numbers\b/i3/' "$CONFIG_FILE"
else
    # Troca i3 -> i3_numbers
    sed -i -E 's/\bi3\b/i3_numbers/' "$CONFIG_FILE"
fi

# Reinicia a Polybar
"$PATH_I3/themes/$current_theme/polybar/launch.sh"

echo "Troca realizada com sucesso!"
