# ┌─┐┌─┐┌┬┐┌─┐┌─┐┬ ┬┌─┐┌─┐┬┌┐┌  ┌┬┐┌─┐┌─┐┌─┐┬ ┬┬┌─┐┌┬┐┌─┐  ┌┬┐┌─┐┌┬┐┌─┐
# │  ├─┤ │ ├─┘├─┘│ ││  │  ││││  │││├─┤│  │  ├─┤│├─┤ │ │ │   │ ├┤ │││├─┤
# └─┘┴ ┴ ┴ ┴  ┴  └─┘└─┘└─┘┴┘└┘  ┴ ┴┴ ┴└─┘└─┘┴ ┴┴┴ ┴ ┴ └─┘   ┴ └─┘┴ ┴┴ ┴

# Colors
background='#24273a'
foreground='#cad3f5'
color0='#494d64'
color1='#ed8796'
color2='#a6da95'
color3='#eed49f'
color4='#8aadf4'
color5='#f5bde6'
color6='#8bd5ca'
color7='#b8c0e0'
color8='#5b6078'
color9='#f5a97f'
color10='#a6da95'
color11='#eed49f'
color12='#8aadf4'
color13='#f5bde6'
color14='#8bd5ca'
color15='#f4dbd6'

accent='#8aadf4'
light_value='0.04'
dark_value='0.25'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Zafiro-Nord-Blue'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='8'

# Geany
geany_colors='catppuccin-macchiato.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='Catppuccin-Macchiato'
icon_theme='Zafiro-Nord-Blue'
cursor_theme='Future'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'

# Picom
picom_backend='glx'
picom_corner='0'
picom_shadow_r='20'
picom_shadow_o='0.50'
picom_shadow_x='-20'
picom_shadow_y='-20'
picom_blur_method='none'
picom_blur_strength='0'

# ------------------------------------------------------------------------------
# Comentários das cores - Catppuccin Macchiato
# ------------------------------------------------------------------------------
# background -> fundo preto-azulado
# foreground -> branco suave (texto padrão)
# color0     -> cinza escuro
# color1     -> vermelho suave
# color2     -> verde claro
# color3     -> amarelo dourado
# color4     -> azul vibrante
# color5     -> rosa/lilás
# color6     -> aqua/verde-azulado
# color7     -> cinza claro
# color8     -> cinza médio
# color9     -> laranja suave
# color10    -> verde claro (bright)
# color11    -> amarelo dourado (bright)
# color12    -> azul vibrante (bright)
# color13    -> rosa/lilás (bright)
# color14    -> aqua/verde-azulado (bright)
# color15    -> rosa pastel
